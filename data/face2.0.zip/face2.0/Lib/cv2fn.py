#-*-coding:utf-8-*-

import cv2
import os
import numpy as np

faceCascade = cv2.CascadeClassifier(os.path.join('Lib', 'haarcascade_frontalface_default.xml'))



def take_picture(num, storageDir = 'picture'):
#	result =1
	if not os.path.exists(storageDir): os.mkdir(storageDir)
	cap = cv2.VideoCapture(0)
	picNum = 1
	if not cap.isOpened(): print('Cap failed because of camera')

	print('Press **SPACE** to capture a picture')
	while 1:
		ret, img = cap.read()
		cv2.imshow('Image',img)
		key = cv2.waitKey(1) & 0xFF
		if key == ord('q'):
			break
		elif key == ord(' '):
			cv2.imshow('Capture Image', img)
			faces = detect_face(img)
			if len(faces) == 1:
				cv2.imwrite(os.path.join(storageDir, 'pic%s.jpg'%picNum), img)
				picNum += 1
				face_state=1
			elif not faces:
				print('No face found')
				face_state=0
				break
			else:
				print('More than one face found')
			if picNum > num: break
	cap.release()
	cv2.destroyAllWindows()
	if face_state ==1:
		return [os.path.join(storageDir, 'pic%s.jpg'%i) for i in range(1, num + 1)]
	else:
		return None
        

def detect_face(img):
	gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
	faces = faceCascade.detectMultiScale(
		gray,     
		scaleFactor=1.2,
		minNeighbors=5,     
		minSize=(20, 20)
	)
	return faces
