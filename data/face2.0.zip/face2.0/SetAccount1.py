#-*-coding:utf-8-*-

import pickle
from Lib.facecpp import *
from Lib.cv2fn import take_picture
from Smart.person import personlist
from Smart.person import Person



#####################     有改动       ##############
import threading
import time
from TeaTime import wechat_time
from PIL import Image
#import matplotlib.pyplot as plt
#####################     有改动       ##############



if not os.path.exists('facedict.pickle'):
	facedict={}
else:
	try:
		f = open('facedict.pickle','rb')
		facedict=pickle.load(f)
		f.close
	except EOFError:
		pass


existFaceName=[]

def SetAccount():
	global personlist
	while 1:
    
        
#        print('Here is the list of faceset recorded:\n' +
#            '\n'.join(['* ' + outer_id for outer_id in existFacesetName]) + '\nEnd of List')

		name = input('What\'s the name of the account you want to set?(q to exit) ')
		if name == 'q': break
		for k,v in facedict.items():
			existFaceName.append(v)
		if name in existFaceName:
			key=list(facedict.keys())[list(facedict.values()).index(name)]
			if input('You will overwrite account [%s]?(y/n) '%name) == 'y':
				removeface(key,'myface')
				del facedict[key]
			else:
				continue

		print('you should input one picture as a sample')
#        picNum = int(input('How much picture do you want to input as sample? ')) or 10
		pictureList = take_picture(1)
		if pictureList is not None:
			faceIdList = upload_img(pictureList)
			print ('%s samples are set'%len(faceIdList))
			for x in faceIdList:
				facedict[x]=name
			f = open('facedict.pickle','wb')
			pickle.dump(facedict,f)
			f.close()
			add_face('myface', faceIdList)
			print('Account [%s] is set'%name)
			user = Person(name) 
			personlist[name] = user


#####################     有改动       ##############
			wechat=input('Do you want to accept from wechat?(y or n)')
			if wechat == 'y':
				im = Image.open('gakki.jpg')
				im.show()
#				plt.imshow('gakki.jpg')
#				plt.pause(10)       #暂停10秒
#				plt.close()
				task = threading.Thread(target=wechat_time,args=(name,))	#线程：得到当前加的好友昵称
				task.start()
			if wechat == 'n':
				break
			break
		else:
			break
#####################     有改动       ##############



if __name__ == '__main__':
	SetAccount()
	
