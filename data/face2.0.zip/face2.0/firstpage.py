#-*-coding:utf-8-*-

import cv2
import numpy
import time
#import uniout
import os
import threading

import RPi.GPIO as GPIO


#####################     有改动       ##############
from Lib.facecpp import *
from Smart.person import personlist
from Smart.person import Person
from TeaTime import time_stamp
import pickle


if not os.path.exists('person_list.pickle'):
    person_list={}
else:
    try:
	    f = open('personlist.pickle','rb')
	    person_list=pickle.load(f)
	    f.close
    except EOFError:
        pass
#####################     有改动       ##############



#初始化
def init():
    #设置不显示警告
    GPIO.setwarnings(False)
    #设置读取面板针脚模式
    GPIO.setmode(GPIO.BOARD)
    #设置读取针脚标号
    GPIO.setup(36,GPIO.IN)
    pass


#####################     有改动       ##############
#备份personlist
def save_personlist():
    f = open('person_list.pickle','wb')
    pickle.dump(personlist,f)
    f.close()
#####################     有改动       ##############


def detct():
    while True:
        #当高电平信号输入时报警
        if GPIO.input(36)==True:
            print ("Hello!")
            task = threading.Thread(target=time_stamp)    #线程：时间戳遍历
            task.start()
            select = input('What do you want to do?(Set account(s) or Remove account(r) or Log in(l) or exit(q))')
            if select == 'q': 
                break
            if select == 's':
                 os.system('python3 SetAccount1.py')
            if select == 'r':
                 os.system('python3 Removeface.py')
            if select == 'l':
                 os.system('python3 Login3.py')
        else:
            continue        #这里可设置为界面显示时钟
        time.sleep(3)


if __name__ == '__main__':
    time.sleep(2)
    init()
    detct()
    GPIO.cleanup()
    save_personlist()           #####################     有改动       ##############