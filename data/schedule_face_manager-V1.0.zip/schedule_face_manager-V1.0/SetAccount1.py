#-*-coding:utf-8-*-

import sys
import pickle
from Lib.facecpp import *
from Lib.cv2fn import take_picture
from person import personlist
from person import Person
#edit by mumumushi 2018/8/14/14:36###########
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from gui.register_window import *

name = ''
isStartRegister = False

class mRegisterWindow(QMainWindow, Ui_register_window):
    def __init__(self, parent = None):
        super(mRegisterWindow, self).__init__(parent)
        self.setupUi(self)


    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()

def enable_btn_camera():
	register_win.btn_camera.setEnable(True)

def start_camera():
	global name
	name = register_win.edit_name.Text()
	#call camera

def start_register():
	global isStartRegister
	if name != '' and name != 'q':
		isStartRegister = True

def close_register():
	global name
	name = 'q'


#existFacesetName = [facesets['outer_id'] for facesets in get_faceset_list()]
if not os.path.exists('facedict.pickle'):
	facedict={}
else:
	try:
		f = open('facedict.pickle','rb')
		facedict=pickle.load(f)
		f.close
	except EOFError:
		pass


existFaceName=[]

def SetAccount():
	global personlist
	while 1:
        
#        print('Here is the list of faceset recorded:\n' +
#            '\n'.join(['* ' + outer_id for outer_id in existFacesetName]) + '\nEnd of List')

		print('What\'s the name of the account you want to set?(q to exit) ')
		while name == '':
			pass

		if name == 'q': break
		for k,v in facedict.items():
			existFaceName.append(v)


		print('you should input one picture as a sample')
#        picNum = int(input('How much picture do you want to input as sample? ')) or 10
		pictureList = take_picture(1)
		if pictureList is not None:
			faceIdList = upload_img(pictureList)
			print ('%s samples are set'%len(faceIdList))
			for x in faceIdList:
				facedict[x]=name
			f = open('facedict.pickle','wb')
			pickle.dump(facedict,f)
			f.close()
			while not isStartRegister:
				pass
			add_face('myface', faceIdList)
			print('Account [%s] is set'%name)
			user = Person(name) 
			personlist[name] = user
			#跳出可以倒计时结束的对话框
			break
		else:
			break


	
