import cv2
import numpy
import time
import uniout

from Lib.facecpp import *
from Lib.cv2fn import take_picture

def login():
    if not os.path.exists('tmp'): os.mkdir('tmp')
    faceCascade = cv2.CascadeClassifier(os.path.join('Lib', 'haarcascade_frontalface_default.xml'))
    capInput = cv2.VideoCapture(0)
    if not capInput.isOpened(): print('Capture failed because of camera')
    while 1:
        existFacesetName = [facesets['outer_id'] for facesets in get_faceset_list()]
        ret, img = capInput.read()
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = faceCascade.detectMultiScale(gray, 1.3, 5)
        if len(faces) > 0:
            picDir = os.path.join('tmp', 'pic.jpg')
            cv2.imwrite(picDir, img)
            pictureId = upload_img(picDir)
            if len(pictureId) > 0:
                while 1:
                    result = compare(existFacesetName, pictureId)
                    if result > 75:
                        print('Login successfully');break
    capInput.release()






if __name__ == '__main__':
    login()
