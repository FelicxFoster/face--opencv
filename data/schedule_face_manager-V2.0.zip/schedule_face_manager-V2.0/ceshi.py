import cv2
import os
 
face_haar = cv2.CascadeClassifier(os.path.join('Lib', 'haarcascade_frontalface_default.xml'))
 
cam = cv2.VideoCapture(0)
 
while True:
	_, img = cam.read()
	gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
 
	faces = face_haar.detectMultiScale(gray_img, 1.3, 5)
	for face_x,face_y,face_w,face_h in faces:
		cv2.rectangle(img, (face_x, face_y), (face_x+face_w, face_y+face_h), (0,255,0), 2)
 
		#roi_gray_img = gray_img[face_y:face_y+face_h, face_x:face_x+face_w]
		#roi_img = img[face_y:face_y+face_h, face_x:face_x+face_w]
 
	cv2.moveWindow('img', 200, 400)
	cv2.imshow('img', img)
	key = cv2.waitKey(30) & 0xff
	if key == 113:
		break
 
cam.release()
cv2.destroyAllWindows()
