#-*-coding:utf-8-*-

import sys
import pickle
from Lib.facecpp import *
from Lib.cv2fn import take_picture
#from person import personlist
from person import Person
import threading
import time
from TeaTime import wechat_time
#edit by mumumushi 2018/8/14/14:36###########
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from gui.register_window import *
import config as gl

name = ''
is_start_camera = False
is_start_register = False

class mRegisterWindow(QMainWindow, Ui_register_window):
    def __init__(self, parent = None):
        super(mRegisterWindow, self).__init__(parent)
        self.setupUi(self)

    def show_QRcode(self):
        replay = QMessageBox.information(self, "你想要添加微信机器人吗", "微信机器人可以帮助您随时随地都能够获得日程提醒", QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        print(replay)
        
    def set_is_start_camera(self):
        global name
        global is_start_camera
		
        name = self.edit_name.Text()
	    #call camera
        if name != '' and name != 'q':
            is_start_camera = True
		    
    def set_is_start_register(self):
        global is_start_register
        if name != '' and name != 'q':
            is_start_register = True
    def set_close_name(self):
        global name
        name = 'q'
		
    def keyPressEvent(self, event):
        if event.key() == QtCore.Qt.Key_Escape:
            self.close()



#existFacesetName = [facesets['outer_id'] for facesets in get_faceset_list()]
if not os.path.exists('facedict.pickle'):
	facedict={}
else:
	try:
		f = open('facedict.pickle','rb')
		facedict=pickle.load(f)
		f.close
	except EOFError:
		pass


existFaceName=[]

def SetAccount(mThread):

##################改动##########################################################	
	gl._init()
#	global personlist

##################改动##########################################################




	global name
	global is_start_camera
	global is_start_register
	while 1:
        
#        print('Here is the list of faceset recorded:\n' +
#            '\n'.join(['* ' + outer_id for outer_id in existFacesetName]) + '\nEnd of List')

		print('What\'s the name of the account you want to set?(q to exit) ')
		
		while name == '':
			pass

		if name == 'q': break
		for k,v in facedict.items():
			existFaceName.append(v)

		while not is_start_camera:
			pass
		#print('you should input one picture as a sample')
#       picNum = int(input('How much picture do you want to input as sample? ')) or 10
		pictureList = take_picture(1)
		if pictureList is not None:
			faceIdList = upload_img(pictureList)
			print ('%s samples are set'%len(faceIdList))
			for x in faceIdList:
				facedict[x]=name
			f = open('facedict.pickle','wb')
			pickle.dump(facedict,f)
			f.close()
			
			#在这里显示二维码询问是否添加微信机器人
			print('Do you want to accept from wechat?(y or n)')
			mThread.trigger_call_window.emit("WECHAT_QRCODE")
			#如果dialog是确认的话，显示二维码，然后十秒后开始线程
			task = threading.Thread(target=wechat_time,args=(name,))	#线程：得到当前加的好友昵称
			task.start()
			
			while not is_start_register:
				pass

			add_face('myface', faceIdList)
			print('Account [%s] is set'%name)
			user = Person(name) 


##################改动##########################################################			
#			personlist[name] = user

			gl.set_personlist('name', user)
			print(gl.get_personlist())

##################改动##########################################################


			break
		else:
			break
	name = ''
	is_start_camera = False
	is_start_register = False



	
