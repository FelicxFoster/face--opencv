# -*- coding:utf-8 -*-

def _init():
    global personlist
    personlist = {}

def set_personlist(name, value):
    personlist[name] = value

def get_personlist(defValue=None):
    try:
        return personlist
    except KeyError:
        return defValue